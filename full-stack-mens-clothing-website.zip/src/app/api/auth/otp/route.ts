import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { otpCodes } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";

const ADMIN_PHONE = "6394038329";

export async function POST(req: NextRequest) {
  try {
    const { phone, action } = await req.json();

    if (action === "send") {
      if (phone !== ADMIN_PHONE) {
        return NextResponse.json({ error: "Unauthorized phone number" }, { status: 403 });
      }
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10000); // 10 seconds only
      await db.insert(otpCodes).values({ phone, code, expiresAt });
      // In production, send SMS. For demo, return the code.
      return NextResponse.json({ message: "OTP sent", otp: code, expiresIn: 10 });
    }

    if (action === "verify") {
      const { code } = await req.json();
      const now = new Date();
      const valid = await db
        .select()
        .from(otpCodes)
        .where(
          and(
            eq(otpCodes.phone, phone),
            eq(otpCodes.code, code),
            eq(otpCodes.used, false),
            gt(otpCodes.expiresAt, now)
          )
        );
      if (valid.length === 0) {
        return NextResponse.json({ error: "Invalid or expired OTP" }, { status: 400 });
      }
      // Mark as used
      await db
        .update(otpCodes)
        .set({ used: true })
        .where(eq(otpCodes.id, valid[0].id));
      return NextResponse.json({ message: "OTP verified" });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
