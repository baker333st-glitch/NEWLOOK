import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { downloadRequests } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const { contactNumber, email } = await req.json();
    if (!contactNumber || !email) {
      return NextResponse.json({ error: "Contact number and email required" }, { status: 400 });
    }

    await db.insert(downloadRequests).values({
      contactNumber,
      email,
      verified: true,
    });

    return NextResponse.json({
      message: "Registration successful! Download link will be sent to your email.",
      downloadUrl: "/api/download/app",
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
