"use client";

export default function MarqueeText() {
  return (
    <div className="w-full overflow-hidden bg-gradient-to-r from-skyblue-dark via-skyblue to-skyblue-dark py-3 border-y border-skyblue/30">
      <div className="animate-marquee whitespace-nowrap">
        <span className="text-xl md:text-2xl font-bold text-white mx-8">
          🔥 NEW LOOK FASHION — Premium Menswear Collection 🔥
        </span>
        <span className="text-xl md:text-2xl font-bold text-yellow-300 mx-8">
          ✨ Wholesale Available ✨
        </span>
        <span className="text-xl md:text-2xl font-bold text-white mx-8">
          📍 3 Branches in Gorakhpur
        </span>
        <span className="text-xl md:text-2xl font-bold text-yellow-300 mx-8">
          💰 Best Prices Guaranteed — Visit Store for More Offers!
        </span>
        <span className="text-xl md:text-2xl font-bold text-white mx-8">
          📞 Contact: 6384038329
        </span>
        <span className="text-xl md:text-2xl font-bold text-yellow-300 mx-8">
          🛒 Order via WhatsApp Only — Cash on Delivery NOT Available
        </span>
        <span className="text-xl md:text-2xl font-bold text-white mx-8">
          💎 UPI Payment Accepted
        </span>
      </div>
    </div>
  );
}
