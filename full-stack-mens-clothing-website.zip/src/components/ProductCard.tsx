"use client";

import { useState } from "react";

interface Product {
  id: number;
  name: string;
  description: string | null;
  imageUrl: string | null;
  price: number;
  discountPrice: number | null;
  sizes: string;
  category: string | null;
  inStock: boolean;
  articleCode: string | null;
}

export default function ProductCard({ product }: { product: Product }) {
  const [zoomed, setZoomed] = useState(false);
  const discount = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const whatsappMsg = encodeURIComponent(
    `Hi! I'm interested in "${product.name}" (Article: ${product.articleCode || "N/A"}) priced at ₹${product.discountPrice || product.price}. Please share details.`
  );
  const whatsappLink = `https://wa.me/916394038329?text=${whatsappMsg}`;

  return (
    <>
      {zoomed && product.imageUrl && (
        <div
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setZoomed(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="max-w-full max-h-[85vh] object-contain rounded-lg"
            />
            <button
              onClick={() => setZoomed(false)}
              className="absolute top-2 right-2 bg-black/70 text-white rounded-full w-10 h-10 flex items-center justify-center text-xl hover:bg-red-600 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>
      )}
      <div className="product-card bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-skyblue/50 transition-all duration-300 group">
        <div
          className="relative aspect-square bg-gray-800 cursor-pointer overflow-hidden"
          onClick={() => product.imageUrl && setZoomed(true)}
        >
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="product-image w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-600">
              <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          )}
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="bg-red-600 text-white px-4 py-2 rounded-full font-bold text-sm">
                OUT OF STOCK
              </span>
            </div>
          )}
          {discount > 0 && (
            <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 rounded-md text-xs font-bold">
              {discount}% OFF
            </div>
          )}
          {product.imageUrl && (
            <div className="absolute top-2 right-2 bg-black/60 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
              </svg>
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="text-white font-semibold text-lg truncate">{product.name}</h3>
          {product.articleCode && (
            <p className="text-skyblue-light text-xs mt-0.5">Article: {product.articleCode}</p>
          )}
          {product.description && (
            <p className="text-gray-400 text-sm mt-1 line-clamp-2">{product.description}</p>
          )}
          <div className="flex items-center gap-2 mt-2">
            {product.discountPrice ? (
              <>
                <span className="text-skyblue font-bold text-xl">₹{product.discountPrice}</span>
                <span className="text-gray-500 line-through text-sm">₹{product.price}</span>
              </>
            ) : (
              <span className="text-skyblue font-bold text-xl">₹{product.price}</span>
            )}
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {product.sizes.split(",").map((s) => (
              <span
                key={s}
                className="bg-gray-800 text-gray-300 px-2 py-0.5 rounded text-xs border border-gray-700"
              >
                {s.trim()}
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-3">
            <span
              className={`px-2 py-0.5 rounded text-xs font-semibold ${
                product.inStock
                  ? "bg-green-900/50 text-green-400 border border-green-800"
                  : "bg-red-900/50 text-red-400 border border-red-800"
              }`}
            >
              {product.inStock ? "✓ In Stock" : "✕ Out of Stock"}
            </span>
            {product.category && (
              <span className="bg-skyblue/10 text-skyblue px-2 py-0.5 rounded text-xs">
                {product.category}
              </span>
            )}
          </div>
          <div className="flex gap-2 mt-3">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-green-600 hover:bg-green-700 text-white text-center py-2 rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-1"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Order Now
            </a>
            <button className="bg-skyblue/20 hover:bg-skyblue/30 text-skyblue px-3 py-2 rounded-lg text-sm transition-colors">
              💳 UPI
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
